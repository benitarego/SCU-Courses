Steps for execution.

1. Run make file
> make 

2. get the final output in output.txt from java Main command
> java Main > output_result.txt

3. You can now open the output file (output_result.txt) to see the result.

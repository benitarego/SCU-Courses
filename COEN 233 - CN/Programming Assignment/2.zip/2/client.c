#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<strings.h>
#include<string.h>
#include<stdint.h>
#include<stdlib.h>
#include<time.h>

#define PORT 8080
#define PAID 0XFFFB
#define NOTPAID 0XFFF9
#define NOTEXIST 0XFFFA
#define TECHNOLOGYMISMATCH 0XFFFC

// Access Permission Request Packet Structure
struct RequestPacket {
	uint16_t packetId;
	uint8_t clientId;
	uint16_t access_permission;
	uint8_t segment_no;
	uint8_t len;
	uint8_t tech;
	unsigned long SourceSubscriberNo;
	uint16_t endPacket;
};


// Response Packet Structure
struct ResponsePacket {
	uint16_t packetId;
	uint8_t clientId;
	uint16_t type;
	uint8_t segment_no;
	uint8_t len;
	uint8_t tech;
	unsigned long SourceSubscriberNo;
	uint16_t endPacket;
};

// To Print Packet Content
void DisplayPacket(struct RequestPacket requestPacket) {
	printf("Packet ID: %x\n",requestPacket.packetId);
	printf("Client ID: %hhx\n",requestPacket.clientId);
	printf("Access Permission: %x\n",requestPacket.access_permission);
	printf("Segment no.: %d\n",requestPacket.segment_no);
	printf("Length of the packet: %d\n",requestPacket.len);
	printf("Technology: %d\n", requestPacket.tech);
	printf("Subscriber no.: %lu\n",requestPacket.SourceSubscriberNo);
	printf("End of Data Packet ID: %x\n",requestPacket.endPacket);
}

// To Intialize Data for Requesting Packet
struct RequestPacket Initialize () {
	struct RequestPacket requestPacket;
	requestPacket.packetId = 0XFFFF;
	requestPacket.clientId = 0XFF;
	requestPacket.access_permission = 0XFFF8;
	requestPacket.endPacket = 0XFFFF;
	return requestPacket;

}

int main(int argc, char**argv) {
	struct RequestPacket requestPacket;
	struct ResponsePacket responsePacket;
	char line[30];
	int i = 1;
	FILE *filePointer;
	int sockfd,n = 0;
	struct sockaddr_in clientAddress;
	socklen_t addr_size;
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	struct timeval timeValue;
	timeValue.tv_sec = 3;  // Timeout
	timeValue.tv_usec = 0;

	// To Check whether the connection has been established
	setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeValue, sizeof(struct timeval));
	int count = 0;
	if(sockfd < 0) {
		printf("Connection Failed!!!\n");
	}
	bzero(&clientAddress, sizeof(clientAddress));
	clientAddress.sin_family = AF_INET;
	clientAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	clientAddress.sin_port = htons(PORT);
	addr_size = sizeof clientAddress ;

	// To Load data into Packet
	requestPacket = Initialize();

	// To read input file
	filePointer = fopen("input.txt", "rt");

	if(filePointer == NULL) {
		printf("Unable to open file!!!\n");
	}

	while(fgets(line, sizeof(line), filePointer) != NULL) {
		count = 0;
		n = 0;
		printf("-------NEW-------\n");
		char * words;
		
		// To Split the line
		words = strtok(line, " ");
		requestPacket.len = strlen(words);
		
		requestPacket.SourceSubscriberNo = (unsigned long) strtol(words, (char **)NULL, 10);
		
		words = strtok(NULL, " ");
		requestPacket.len += strlen(words);
		requestPacket.tech = atoi(words);
		words = strtok(NULL, " ");
		requestPacket.segment_no = i;
		// To Print Contents of the Packet
		DisplayPacket(requestPacket);
		while(n <= 0 && count < 3) { // Check if packet sent, if not tries again.
			sendto(sockfd, &requestPacket, sizeof(struct RequestPacket), 0, (struct sockaddr *)&clientAddress, addr_size);
			// To Receive response from the Server
			n = recvfrom(sockfd, &responsePacket, sizeof(struct ResponsePacket), 0, NULL, NULL);
			if(n <= 0) {
				// If there is No response
				printf("Out of Time!!!\n");
				count ++;
			} else if(n > 0) {
				// When the Response is recieved
				printf("Status = ");
				if(responsePacket.type == NOTPAID) {
					printf("Subscriber has not paid!!!\n");
				} else if(responsePacket.type == NOTEXIST) {
					printf("Subsriber does not exist!!!\n");
				} else if(responsePacket.type == PAID) {
					printf("Subsriber permitted to access the network!\n");
				} else if(responsePacket.type == TECHNOLOGYMISMATCH) {
					printf("Subscriber found but Technology doesn't match!!!\n");
				}
			}
		}

		// After 5 attempts id the Server is not responding
		if(count >= 5) {
			printf("Server is not responding!!!");
			exit(0);
		}
		i++;
	}
	fclose(filePointer);
}
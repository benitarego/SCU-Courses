Name: Benita Rego
Ecampus ID: W1628656

Step 1: Run Server Code first:
		gcc -o server server.c 
		./server

Step 2: Run Client Code after the server is running:
		gcc -o client client.c
		./client
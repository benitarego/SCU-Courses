#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<strings.h>
#include<string.h>
#include<stdint.h>
#include<stdlib.h>
#include<unistd.h>

#define PORT 8080
#define LENGTH 10
#define PAID 0XFFFB
#define NOTPAID 0XFFF9
#define NOTEXIST 0XFFFA
#define TECHNOLOGYMISMATCH 0XFFFC

// Access Permission Request Packet Structure
struct RequestPacket{
	uint16_t packetID;
	uint8_t clientID;
	uint16_t access_permission;
	uint8_t segment_no;
	uint8_t len;
	uint8_t tech;
	unsigned long long SourceSubscriberNo;
	uint16_t endpacketID;
};

// Response Packet Structure
struct ResponsePacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint8_t segment_no;
	uint8_t len;
	uint8_t tech;
	unsigned long SourceSubscriberNo;
	uint16_t endpacketID;
};

// To Store Subscriber info
struct SubscriberDatabase {
	unsigned long subscriberNo;
	uint8_t tech;
	int status;
};

// To Printing Packet Content
void displayPacket(struct RequestPacket requestPacket ) {
	printf("\nPacket ID: %x\n",requestPacket.packetID);
	printf("Client ID: %hhx\n",requestPacket.clientID);
	printf("Access Permission: %x\n",requestPacket.access_permission);
	printf("Segment no: %d\n",requestPacket.segment_no);
	printf("Length of the Packet: %d\n",requestPacket.len);
	printf("Technology: %d\n", requestPacket.tech);
	printf("Subscriber no: %llu\n", requestPacket.SourceSubscriberNo);
	printf("End of Request Packet ID: %x\n",requestPacket.endpacketID);
}


// To Create Response Packet
struct ResponsePacket generateResponsePacket(struct RequestPacket requestPacket) {
	struct ResponsePacket responsePacket;
	responsePacket.packetID = requestPacket.packetID;
	responsePacket.clientID = requestPacket.clientID;
	responsePacket.segment_no = requestPacket.segment_no;
	responsePacket.len = requestPacket.len;
	responsePacket.tech = requestPacket.tech;
	responsePacket.SourceSubscriberNo = requestPacket.SourceSubscriberNo;
	responsePacket.endpacketID = requestPacket.endpacketID;
	return responsePacket;
}

// To Map
void readFile(struct SubscriberDatabase subscriberDatabase[]) {
	// Read file and store the contents
	char line[30];
	int i = 0;
	FILE *filePointer;

	filePointer = fopen("VerificationDatabase.txt", "rt");

	if(filePointer == NULL) {
		printf("Unable to open file!!!\n");
		return;
	}
	while(fgets(line, sizeof(line), filePointer) != NULL) {
		char * words = NULL;
		words = strtok(line, " ");
		subscriberDatabase[i].subscriberNo = (unsigned) atol(words);     // long int
		words = strtok(NULL, " ");
		subscriberDatabase[i].tech = atoi(words);						// int
		words = strtok(NULL, " ");
		subscriberDatabase[i].status = atoi(words);
		i++;
	}
	fclose(filePointer);
}

// To Check whether the Subscriber Exists
int check(struct SubscriberDatabase subscriberDatabase[], unsigned int subscriberNo, uint8_t tech) {
	int value = -1;
	for(int j=0; j<LENGTH; j++) {
		if(subscriberDatabase[j].subscriberNo == subscriberNo && subscriberDatabase[j].tech == tech) {
			return subscriberDatabase[j].status;
		} else if(subscriberDatabase[j].subscriberNo == subscriberNo && subscriberDatabase[j].tech != tech)
            return 2;
	}
	return value;
}

int main(int argc, char**argv) {
    struct RequestPacket requestPacket;
	struct ResponsePacket responsePacket;
	struct SubscriberDatabase subscriberDatabase[LENGTH];
	readFile(subscriberDatabase);
	
    int sockfd,n;
	struct sockaddr_in serverAddress;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	
    bzero(&serverAddress, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddress.sin_port = htons(PORT);
	
    bind(sockfd, (struct sockaddr *)&serverAddress, sizeof(serverAddress));
	addr_size = sizeof serverAddress;
	printf("Server running successfully!\n");
	
	for (;;) {
		// To Get the packet
		n = recvfrom(sockfd, &requestPacket, sizeof(struct RequestPacket), 0, (struct sockaddr *)&serverStorage, &addr_size);
		displayPacket(requestPacket);
		if(requestPacket.segment_no == 11) {
			exit(0);
		}
		if(n>0 && requestPacket.access_permission == 0XFFF8) {
			// The Response Packet
			responsePacket = generateResponsePacket(requestPacket);
			int value = check(subscriberDatabase, requestPacket.SourceSubscriberNo, requestPacket.tech);
			if(value == 0) {
				responsePacket.type = NOTPAID;
				printf("Subscriber has not paid!!!\n");
			} else if(value == 1) {
				printf("Subscriber has paid!\n");
				responsePacket.type = PAID;
			} else if(value == -1) {
				printf("Subscriber does not exist on database!!!\n");
				responsePacket.type = NOTEXIST;
			} else{                
                printf("Subscriber's technology does not match!!!\n");
            	responsePacket.type = TECHNOLOGYMISMATCH;
            }                        
			// To send the Packet for Response
			sendto(sockfd, &responsePacket, sizeof(struct ResponsePacket), 0, (struct sockaddr *)&serverStorage, addr_size);
		}
		n = 0;
	}
}




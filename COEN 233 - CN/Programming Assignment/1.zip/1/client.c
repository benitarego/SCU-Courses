#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<strings.h>
#include<string.h>
#include<stdint.h>
#include<stdlib.h>
#include<time.h>

#define PORTNO 8081
#define PACKETID 0XFFFF
#define CLIENTID 0XFF
#define DATATYPE 0XFFF1
#define ENDPACKETID 0XFFFF
#define TIMEOUT 3
#define ACKPACKET 0XFFF2
#define REJECTPACKETCODE 0XFFF3
#define LENGTHMISMATCHCODE 0XFFF5
#define ENDPACKETIDMISSINGCODE 0XFFF6
#define OUTOFSEQUENCECODE 0XFFF4
#define DUPLICATECODE 0XFFF7

struct DataPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint8_t sequence_no;
	uint8_t len;
	char payload[255];
	uint16_t endpacketID;
};

struct AckPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint8_t sequence_no;
	uint16_t endpacketID;
};

struct RejectPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint16_t subcode;
	uint8_t sequence_no;
	uint16_t endpacketID;
};

struct DataPacket initialise() {
	struct DataPacket data;
	data.packetID = PACKETID;
	data.clientID = CLIENTID;
	data.type = DATATYPE;
	data.endpacketID = ENDPACKETID;
	return data;
}

struct AckPacket ackinitialise() {
	struct AckPacket data;
	data.packetID = PACKETID;
	data.clientID = CLIENTID;
	data.type = ACKPACKET;
	data.endpacketID = ENDPACKETID;
	return data;
}

struct RejectPacket rejinitialise() {
	struct RejectPacket data;
	data.packetID = PACKETID;
	data.clientID = CLIENTID;
	data.type = ACKPACKET;
	data.endpacketID = ENDPACKETID;
	return data;
}

void print(struct DataPacket data) {
	printf("Packet ID: %x\n", data.packetID);
	printf("Client ID: %hhx\n", data.clientID);
	printf("Data: %x\n", data.type);
	printf("Sequence no.: %d\n", data.sequence_no);
	printf("Length: %d\n", data.len);
	printf("Pay Load: %s", data.payload);
	printf("End of Data Packet ID: %x\n", data.endpacketID);
	printf("\n");
}

void ackprint(struct AckPacket adata) {
	printf("Packet ID: %x\n", adata.packetID);
	printf("Client ID: %x\n", adata.clientID);
	printf("Data: %x\n", adata.type);
	printf("Sequence no.: %d\n", adata.sequence_no+1);
	printf("End of Data Packet ID: %x\n", adata.endpacketID);
	printf("\n");
}

void rejprint(struct RejectPacket rdata) {
	printf("Packet ID: %x\n", rdata.packetID);
	printf("Client ID: %hhx\n", rdata.clientID);
	printf("Data: %x\n", rdata.type);
	printf("Sequence no.: %d\n", rdata.sequence_no+1);
	printf("Reject: fff3\n");
	printf("Subcode: %x\n", rdata.subcode);
	printf("End of Data Packet ID: %x\n", rdata.endpacketID);
	printf("\n");
}

int main() {
	struct DataPacket data;
	struct RejectPacket recievedpacket;
	struct sockaddr_in cliaddr;
	struct AckPacket ackdata;
	struct RejectPacket rejdata;
	socklen_t addr_size;
	FILE *fp;

	char line[255];
	int sockfd;
	int n = 0;
	int counter = 0;
	int sequenceNo = 1;
	int check = 0;
	
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	if(sockfd < 0) {
		printf("Socket failed!!!\n");
	}

	bzero(&cliaddr, sizeof(cliaddr));
	cliaddr.sin_family = AF_INET;
	cliaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	cliaddr.sin_port = htons(PORTNO);
	addr_size = sizeof cliaddr ;
	struct timeval tv;
	tv.tv_sec = TIMEOUT;  
	tv.tv_usec = 0;
	setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(struct timeval));
	fp = fopen("input.txt", "rt");
	
	if(fp == NULL) {
		printf("Unable to open file!!!\n");
		exit(0);
	}
	
	while(1) {
		printf("1. Send packet to server\n");
		printf("2. Length mismatch\n");
		printf("3. End of packet error\n");
		printf("4. Out of sequence error or duplicate packet\n");
		int i;
		scanf("%d", &i);
		check = 0;
		data = initialise();
		ackdata = ackinitialise();
		rejdata = rejinitialise();
	   
		if(fgets(line, sizeof(line), fp) != NULL) {
			n = 0;
			counter = 0;
			printf("%s",line);
			data.sequence_no = sequenceNo;
			strcpy(data.payload,line);
			data.len = strlen(data.payload);
			data.endpacketID = ENDPACKETID;
		}
		
	   	switch(i) {
			case 1:
				break;		
			case 2:
				data.len++;
				break;
			case 3:
				data.endpacketID = 0;
				break;
			case 4:
				data.sequence_no = 4; 
				break;
			default:
				printf("Invalid option selected");
				check = 1;
		}

		if(check == 0) {
			while(n<=0 && counter<3) {
				sendto(sockfd, &data, sizeof(struct DataPacket), 0, (struct sockaddr *)&cliaddr, addr_size);
				n = recvfrom(sockfd, &recievedpacket, sizeof(struct RejectPacket), 0, NULL, NULL);
				if(n <= 0) {
					printf("No response from server for three seconds. Sending the packet again!\n");
					counter++;
				} else if(recievedpacket.type == ACKPACKET) {
					print(data);
					printf("Acknowledge packet recieved!\n");
					ackdata.sequence_no = data.sequence_no-1;
					ackprint(ackdata);
				} else if(recievedpacket.type == REJECTPACKETCODE) {
					printf("Reject Packet recieved!\n");
					rejdata.subcode = recievedpacket.subcode;
					rejdata.sequence_no = data.sequence_no-1;

					if(recievedpacket.subcode == LENGTHMISMATCHCODE) {
						printf("Length mismatch error!\n");
					}
					if(recievedpacket.subcode == ENDPACKETIDMISSINGCODE) {
						printf("End of packet identifier missing!!!\n");
					}
					if(recievedpacket.subcode == OUTOFSEQUENCECODE) {
						printf("Out of sequence error!!!\n");
					}
					if(recievedpacket.subcode == DUPLICATECODE) {
						printf("Duplicate packet received by the server!!!\n");
					}
					rejprint(rejdata);
				}
			}
			if(counter >= 3) {
				printf("Server does not respond");
				exit(0);
			}
			sequenceNo++;
		}
	}
}

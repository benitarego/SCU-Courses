#include<sys/socket.h>
#include<netinet/in.h>
#include<stdio.h>
#include<strings.h>
#include<string.h>
#include<stdint.h>
#include<stdlib.h>
#include<unistd.h>

#define PORT 8081
#define PACKETID 0XFFFF
#define CLIENTID 0XFF
#define DATATYPE 0XFFF1
#define ENDPACKETID 0XFFFF
#define TIMEOUT 1
#define ACKPACKET 0XFFF2
#define REJECTPACKETCODE 0XFFF3
#define LENGTHMISMATCHCODE 0XFFF5
#define ENDPACKETIDMISSINGCODE 0XFFF6
#define OUTOFSEQUENCECODE 0XFFF4
#define DUPLICATECODE 0XFFF7

struct DataPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint8_t sequence_no;
	uint8_t len;
	char payload[255];
	uint16_t endpacketID;
};

struct AckPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint8_t sequence_no;
	uint16_t endpacketID;
};

struct RejectPacket {
	uint16_t packetID;
	uint8_t clientID;
	uint16_t type;
	uint16_t subcode;
	uint8_t sequence_no;
	uint16_t endpacketID;
};

void show(struct DataPacket data) {
	printf("Received packet details:\n");
	printf("Packet ID: %hx\n", data.packetID);
	printf("Client ID: %hhx\n", data.clientID);
	printf("Data: %x\n", data.type);
	printf("Sequence no.: %d\n", data.sequence_no);
	printf("Length: %d\n", data.len);
	printf("Pay Load: %s\n", data.payload);
	printf("End of Packet ID: %x\n", data.endpacketID);
}

struct RejectPacket generaterejectpacket(struct DataPacket data) {
	struct RejectPacket reject;
	reject.packetID = data.packetID;
	reject.clientID = data.clientID;
	reject.sequence_no = data.sequence_no;
	reject.type = REJECTPACKETCODE;
	reject.endpacketID = data.endpacketID;
	return reject;
}

struct AckPacket generateackpacket(struct DataPacket data) {
	struct AckPacket ack;
	ack.packetID = data.packetID;
	ack.clientID = data.clientID;
	ack.sequence_no = data.sequence_no;
	ack.type = ACKPACKET;
	ack.endpacketID = data.endpacketID;
	return ack;
}

int main(int argc, char**argv) {
	int sockfd,n;
	struct sockaddr_in serverAddr;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;
	struct DataPacket data;
	struct AckPacket ack;
	struct RejectPacket reject;

	int buffer[20];
	int j;

	for(j=0; j<20; j++) {
		buffer[j] = 0;
	}

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	int expectedPacket = 1;
	bzero(&serverAddr, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serverAddr.sin_port = htons(PORT);
	bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
	addr_size = sizeof serverAddr;
	printf("Server started!\n");
	
	for(; ;) {
		n = recvfrom(sockfd, &data, sizeof(struct DataPacket), 0, (struct sockaddr *)&serverStorage, &addr_size);
		printf("New: \t");
		show(data);
		buffer[data.sequence_no]++;
		if(data.sequence_no == 10 || data.sequence_no == 11) {
			buffer[data.sequence_no] = 1;
		}

		int length = strlen(data.payload);

		if(buffer[data.sequence_no] != 1) {
			reject = generaterejectpacket(data);
			reject.subcode = DUPLICATECODE;
			sendto(sockfd, &reject, sizeof(struct RejectPacket), 0, (struct sockaddr *)&serverStorage, addr_size);
			printf("Duplicate packet received!!!\n");
		} else if(length != data.len) {
			reject = generaterejectpacket(data);
			reject.subcode = LENGTHMISMATCHCODE ;
			sendto(sockfd, &reject, sizeof(struct RejectPacket), 0, (struct sockaddr *)&serverStorage, addr_size);
			printf("Length mismatch error!!!\n");
		} else if(data.endpacketID != ENDPACKETID) {
			reject = generaterejectpacket(data);
			reject.subcode = ENDPACKETIDMISSINGCODE ;
			sendto(sockfd, &reject, sizeof(struct RejectPacket), 0, (struct sockaddr *)&serverStorage, addr_size);
			printf("End of packet identifier missing!!!\n");
		} else if(data.sequence_no != expectedPacket && data.sequence_no != 10 && data.sequence_no != 11) {
			reject = generaterejectpacket(data);
			reject.subcode = OUTOFSEQUENCECODE;
			sendto(sockfd, &reject, sizeof(struct RejectPacket), 0, (struct sockaddr *)&serverStorage, addr_size);
			printf("Out of sequence error!!!\n");
		} else {
			if(data.sequence_no == 10) {
				sleep(15);
			}
			ack = generateackpacket(data);
			sendto(sockfd, &ack, sizeof(struct AckPacket), 0, (struct sockaddr *)&serverStorage, addr_size);
		}
		expectedPacket++;
	}
}
